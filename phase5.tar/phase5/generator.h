#ifndef GENERATOR_H
#define GENERATOR_H

#include "scope.h"

void declareGlobals(Scope *scope);

#endif
